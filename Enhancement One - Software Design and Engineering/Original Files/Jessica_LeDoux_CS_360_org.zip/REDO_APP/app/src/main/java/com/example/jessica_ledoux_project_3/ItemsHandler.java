package com.example.jessica_ledoux_project_3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ItemsHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "ItemsData.DB";
    private static final String TABLE_NAME = "ItemsTable";

    private static final String ITEM_NAME_COL = "id";
    private static final String USER_EMAIL_COL = "email";
    private static final String DESCRIPTION_COL = "description";
    private static final String QUANTITY_COL = "quantity";
    private static final String UNIT_COL = "unit";

    private static final String CREATE_ITEMS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            ITEM_NAME_COL + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            USER_EMAIL_COL + " VARCHAR, " +
            DESCRIPTION_COL + " VARCHAR, " +
            QUANTITY_COL + " VARCHAR, " +
            UNIT_COL + " VARCHAR" + ");";

    public ItemsHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /**
     * Database CRUD (Create, Read, Update, Delete) Operations
     */

    // Adding item and all its variables to database
    public void createItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USER_EMAIL_COL, item.getUserEmail());
        values.put(DESCRIPTION_COL, item.getDesc());
        values.put(QUANTITY_COL, item.getQty());
        values.put(UNIT_COL, item.getCategory());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Reading item variables from database
    public Item readItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME,
                new String[] {ITEM_NAME_COL, USER_EMAIL_COL, DESCRIPTION_COL, QUANTITY_COL, UNIT_COL }, ITEM_NAME_COL + " = ?",
                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        Item item = new Item(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));

        cursor.close();

        return item;
    }

    // Updating the item variables in the database
    public int updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USER_EMAIL_COL, item.getUserEmail());
        values.put(DESCRIPTION_COL, item.getDesc());
        values.put(QUANTITY_COL, item.getQty());
        values.put(UNIT_COL, item.getCategory());

        return db.update(TABLE_NAME, values, ITEM_NAME_COL + " = ?", new String[] { String.valueOf(item.getItem_name()) });
    }

    // Deleting items variables from the database
    public void deleteItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, ITEM_NAME_COL + " = ?", new String[] { String.valueOf(item.getItem_name()) });
        db.close();
    }

    /**
     * Global Database Operations
     */

    // List to get all items from Array
    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // Adding to the list by a do loop
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setItem_name(Integer.parseInt(cursor.getString(0)));
                item.setUserEmail(cursor.getString(1));
                item.setDesc(cursor.getString(2));
                item.setQty(cursor.getString(3));
                item.setCategory(cursor.getString(4));

                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return itemList;
    }

    // Deleting all item variables from the database
    public void deleteAllItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME,null,null);
        db.close();
    }

    // Getting total item count from the database
    public int getItemsCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int itemsTotal = cursor.getCount();
        cursor.close();

        return itemsTotal;
    }
}

