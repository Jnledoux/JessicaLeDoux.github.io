package com.example.jessica_ledoux_project_3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;

public class AddItem extends AppCompatActivity {

    String Email_Holder, Desc_Holder, Qty_Holder, Category_Holder;
    TextView UserEmail;
    ImageButton Increase_Qty, Decrease_Qty;
    EditText ItemDescValue, ItemQtyValue, ItemCategoryValue;
    Button Cancel_Button, Add_Item_Button;
    Boolean EmptyHolder;
    ItemsHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);

        // Initiate variables, buttons, and databases
        UserEmail = findViewById(R.id.current_logged_user);
        ItemDescValue = findViewById(R.id.item_desc);
        ItemCategoryValue = findViewById(R.id.item_category);
        Increase_Qty = findViewById(R.id.item_qty_inc);
        Decrease_Qty = findViewById(R.id.item_qty_dec);
        ItemQtyValue = findViewById(R.id.item_quantity);
        Cancel_Button = findViewById(R.id.add_cancel_button);
        Add_Item_Button = findViewById(R.id.add_item_button);
        db = new ItemsHandler(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Receiving user email sent by login
        Email_Holder = intent.get().getStringExtra(InventoryGrid.UserEmail);

        // Setting user email on current logged user
        UserEmail.setText(getString(R.string.logged_user, Email_Holder));

        // Adding click listener to increase qty
        Increase_Qty.setOnClickListener(view -> {
            int input = 0, total;

            String value = ItemQtyValue.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }

            total = input + 1;
            ItemQtyValue.setText(String.valueOf(total));
        });

        // Adding click listener to decrease qty
        Decrease_Qty.setOnClickListener(view -> {
            int input, total;

            String qty = ItemQtyValue.getText().toString().trim();

            if (qty.equals("0")) {
                Toast.makeText(this, "Item Quantity is Zero", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(qty);
                total = input - 1;
                ItemQtyValue.setText(String.valueOf(total));
            }
        });

        // Adding click listener for cancel button
        Cancel_Button.setOnClickListener(view -> {
            // Returning to add item after cancel
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        // Adding click listener to add item and put in item database
        Add_Item_Button.setOnClickListener(view -> InsertItemIntoDatabase());
    }

    // Insert item into database
    public void InsertItemIntoDatabase() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
            String email = Email_Holder;
            String desc = Desc_Holder;
            String qty = Qty_Holder;
            String unit = Category_Holder;

            Item item = new Item(email, desc, qty, unit);
            db.createItem(item);

            // Message to confirm successful addition
            Toast.makeText(this,"Item Added Successfully", Toast.LENGTH_LONG).show();

            // Close AddItemActivity
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {
            // Message if the description is empty
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking to ensure item description is not empty
    public String CheckEditTextNotEmpty() {
        // Getting and storing values into holders
        String message = "";
        Desc_Holder = ItemDescValue.getText().toString().trim();
        Category_Holder = ItemCategoryValue.getText().toString().trim();
        Qty_Holder = ItemQtyValue.getText().toString().trim();

        if (Desc_Holder.isEmpty()) {
            ItemDescValue.requestFocus();
            EmptyHolder = true;
            message = "Item Description is Empty";
        } else if (Category_Holder.isEmpty()){
            ItemCategoryValue.requestFocus();
            EmptyHolder = true;
            message = "Item Unit is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

}
