package com.example.jessica_ledoux_project_3;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;

import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    EditText emailInput, passwordInput;
    Button login_button, newUser_button, forgot_button;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    PopupWindow popwindow;
    SQLiteDatabase UserDB;
    UsersHandler dbHandler;
    String TempPassword = "NOT_FOUND";
    Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activity = this;

        // Initiate variables, buttons, and databases
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);
        login_button = findViewById(R.id.login_button);
        forgot_button = findViewById(R.id.forgot_button);
        newUser_button = findViewById(R.id.newUser_button);
        dbHandler = new UsersHandler(this);

        // Adding click listener for login function
        login_button.setOnClickListener(view -> {
            LoginFunction();
        });

        // Adding click listener to register a new user
        newUser_button.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, NewUserReg.class);
            startActivity(intent);
        });

        // Adding click listener for forgotten password popup
        forgot_button.setOnClickListener(view -> {
            EmailHolder = emailInput.getText().toString().trim();

            if (!EmailHolder.isEmpty()) {
                forgotPassPopup();
            } else {
                Toast.makeText(MainActivity.this, "User Email is Empty", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Login function
    public void LoginFunction() {
        String message = CheckEditTextNotEmpty();

        if(!EmptyHolder) {
            // Opening the user database
            UserDB = dbHandler.getWritableDatabase();

            // Searching for email
            Cursor cursor = UserDB.query(UsersHandler.TABLE_NAME, null, " " + UsersHandler.EMAIL_COL + "=?", new String[]{EmailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Holding variables from user database
                    TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersHandler.PASSWORD_COL));
                    NameHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersHandler.NAME_COL));
                    PhoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersHandler.PHONE_NUMBER_COL));

                    // Closing
                    cursor.close();
                }
            }
            dbHandler.close();

            CheckFinalResult();
        } else {
            // Message if anything is left empty
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    public String CheckEditTextNotEmpty() {
        // Holder for variables
        String message = "";
        EmailHolder = emailInput.getText().toString().trim();
        PasswordHolder = passwordInput.getText().toString().trim();

        if (EmailHolder.isEmpty()){
            emailInput.requestFocus();
            EmptyHolder = true;
            message = "User Email is Empty";
        } else if (PasswordHolder.isEmpty()){
            passwordInput.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(MainActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            // Bundling holder to send for inventory grid
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);
            bundle.putString("user_email", EmailHolder);
            bundle.putString("user_phone", PhoneNumberHolder);

            // Going to inventory grid
            Intent intent = new Intent(MainActivity.this, InventoryGrid.class);
            intent.putExtras(bundle);
            startActivity(intent);

            EmptyEditTextAfterDataInsert();
        } else {
            // Message if an error occurs
            Toast.makeText(MainActivity.this,"Incorrect Email or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // Clear and empty text for the two inputs
    public void EmptyEditTextAfterDataInsert() {
        emailInput.getText().clear();
        passwordInput.getText().clear();
    }

    public void forgotPassPopup() {
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.forgot_password, activity.findViewById(R.id.forgot_popup_element));

        popwindow = new PopupWindow(layout, 800, 800, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        // Opening the user database
        UserDB = dbHandler.getWritableDatabase();

        // Adding email search
        Cursor cursor = UserDB.query(UsersHandler.TABLE_NAME, null, " " + UsersHandler.EMAIL_COL + "=?", new String[]{EmailHolder}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();

                // Holding variables from user database
                PhoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersHandler.PHONE_NUMBER_COL));
                TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersHandler.PASSWORD_COL));

                // Closing
                cursor.close();
            }
        }
        dbHandler.close();

        Button sendMsg = layout.findViewById(R.id.forgot_send_msg);
        Button cancel = layout.findViewById(R.id.forgot_cancel_button);

        cancel.setOnClickListener(view -> {
            Toast.makeText(activity, "Action Canceled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
    }
}
