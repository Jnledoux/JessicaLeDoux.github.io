package com.example.jessica_ledoux_project_3;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SendSMS extends AppCompatActivity {

    public static AlertDialog doubleButton(final InventoryGrid context){
        // Using a builder class for messages
        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        builder.setTitle(R.string.sms_title)
                .setIcon(R.drawable.sms_message)
                .setCancelable(false)
                .setMessage(R.string.sms_msg)
                .setPositiveButton(R.string.enable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Enable", Toast.LENGTH_LONG).show();
                    InventoryGrid.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.disable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Disable", Toast.LENGTH_LONG).show();
                    InventoryGrid.DenySendSMS();
                    dialog.cancel();
                });

        return builder.create();
    }
}