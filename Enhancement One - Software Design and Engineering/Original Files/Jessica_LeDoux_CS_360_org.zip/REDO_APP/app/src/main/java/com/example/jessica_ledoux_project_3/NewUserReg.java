package com.example.jessica_ledoux_project_3;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewUserReg extends AppCompatActivity {

    Button Reg_Button, Cancel_Button;
    EditText Name_Holder, Phone_Holder, Email_Holder, Password_Holder;
    Boolean EmptyHolder;
    SQLiteDatabase UserDB;
    UsersHandler dbHandler;
    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initiate variables, buttons, and databases
        Name_Holder = findViewById(R.id.user_name);
        Phone_Holder = findViewById(R.id.user_phoneNum);
        Email_Holder = findViewById(R.id.user_email);
        Password_Holder = findViewById(R.id.user_password);
        Reg_Button = findViewById(R.id.sign_up_button);
        Cancel_Button = findViewById(R.id.cancel_button);
        dbHandler = new UsersHandler(this);

        // Adding click listener for registration button
        Reg_Button.setOnClickListener(view -> {
            String message = CheckEditTextNotEmpty();

            if (!EmptyHolder) {
                // Check if email already exists
                CheckEmailAlreadyExists();
                // Clear and empty
                EmptyEditTextAfterDataInsert();
            } else {
                // Message if empty
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        // Adding click listener to cancel
        Cancel_Button.setOnClickListener(view -> {
            // Returning to login in MainActivity
            startActivity(new Intent(NewUserReg.this, MainActivity.class));
            this.finish();
        });

    }

    // Register new user into database
    public void InsertUserIntoDatabase(){
        String name = Name_Holder.getText().toString().trim();
        String phone = Phone_Holder.getText().toString().trim();
        String email = Email_Holder.getText().toString().trim();
        String pass = Password_Holder.getText().toString().trim();

        User user = new User(name, phone, email, pass);
        dbHandler.createUser(user);

        // Message if successful
        Toast.makeText(NewUserReg.this,"User Registered Successfully", Toast.LENGTH_LONG).show();

        // Returning to login in MainActivity
        startActivity(new Intent(NewUserReg.this, MainActivity.class));
        this.finish();
    }


    public String CheckEditTextNotEmpty() {
        // Holding variables
        String message = "";
        String name = Name_Holder.getText().toString().trim();
        String phone = Phone_Holder.getText().toString().trim();
        String email = Email_Holder.getText().toString().trim();
        String pass = Password_Holder.getText().toString().trim();

        if (name.isEmpty()) {
            Name_Holder.requestFocus();
            EmptyHolder = true;
            message = "User Name is Empty";
        } else if (phone.isEmpty()){
            Phone_Holder.requestFocus();
            EmptyHolder = true;
            message = "User Phone is Empty";
        } else if (email.isEmpty()){
            Email_Holder.requestFocus();
            EmptyHolder = true;
            message = "User Email is Empty";
        } else if (pass.isEmpty()){
            Password_Holder.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    public void CheckEmailAlreadyExists(){
        String email = Email_Holder.getText().toString().trim();
        UserDB = dbHandler.getWritableDatabase();

        // Search for email
        Cursor cursor = UserDB.query(UsersHandler.TABLE_NAME, null, " " + UsersHandler.EMAIL_COL + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // Display message if email is found
                F_Result = "Email Found";
                // Closing
                cursor.close();
            }
        }
        dbHandler.close();

        CheckFinalCredentials();
    }

    public void CheckFinalCredentials(){
        if(F_Result.equalsIgnoreCase("Email Found"))
        {
            // Display message if email is found
            Toast.makeText(NewUserReg.this,"Email Already Exists",Toast.LENGTH_LONG).show();
        }
        else {
            // add to database if email doesn't exist
            InsertUserIntoDatabase();
        }
        F_Result = "Not_Found" ;
    }

    // Clear and empty holders
    public void EmptyEditTextAfterDataInsert(){
        Name_Holder.getText().clear();
        Phone_Holder.getText().clear();
        Email_Holder.getText().clear();
        Password_Holder.getText().clear();
    }

}

