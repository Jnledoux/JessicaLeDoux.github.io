package com.example.jessica_ledoux_project_3;

public class Item {
    int item_name;
    String user_email;
    String item_list_desc;
    String item_list_quantity;
    String item_list_category;

    public Item() {
        super();
    }

    public Item(int i, String email, String description, String quantity, String category) {
        super();
        this.item_name = i;
        this.user_email = email;
        this.item_list_desc = description;
        this.item_list_quantity = quantity;
        this.item_list_category = category;
    }

    // constructor for variables
    public Item(String email, String description, String quantity, String category) {
        this.user_email = email;
        this.item_list_desc = description;
        this.item_list_quantity = quantity;
        this.item_list_category =category;
    }

    public int getItem_name() {
        return item_name;
    }

    public void setItem_name(int item_name) {
        this.item_name = item_name;
    }

    public String getUserEmail() {
        return user_email;
    }

    public void setUserEmail(String user_email) {
        this.user_email = user_email;
    }

    public String getDesc() {
        return item_list_desc;
    }

    public void setDesc(String desc) {
        this.item_list_desc = desc;
    }

    public String getQty() {
        return item_list_quantity;
    }

    public void setQty(String qty) {
        this.item_list_quantity = qty;
    }

    public String getCategory() {return item_list_category;}

    public void setCategory(String unit) {
        this.item_list_category = unit;
    }
}

