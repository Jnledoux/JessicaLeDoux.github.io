package com.example.jessica_ledoux_project_3;

// Add this class to deal with the three new roles added to the application
public class RolePermissions {

    public static boolean canViewReports(String role) {
        // Manager and Clerk roles can view reports
        return role.equals("Manager") || role.equals("Clerk");
    }

    public static boolean canManageUsers(String role) {
        // Only Manager roles can manage users
        return role.equals("Manager");
    }

    public static boolean canEditInventory(String role) {
        return role.equals("Manager");
    }

    public static boolean canViewLogs(String role) {
        return role.equals("Manager");
    }
}