package com.example.jessica_ledoux_project_3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ItemsHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "ItemsData.DB";
    private static final String TABLE_NAME = "ItemsTable";

    // Column names
    private static final String COL_ID = "itemId";
    private static final String COL_NAME = "name";
    private static final String COL_EMAIL = "email";
    private static final String COL_PRICE = "price";
    private static final String COL_QTY = "quantity";
    private static final String COL_UNIT = "unit";

    // Table creation SQL
    private static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" +
            COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_NAME + " TEXT, " +
            COL_EMAIL + " TEXT, " +
            COL_PRICE + " TEXT, " +
            COL_QTY + " TEXT, " +
            COL_UNIT + " TEXT);";

    public ItemsHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Create a new item
    public void createItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, item.getitemName());
        values.put(COL_EMAIL, item.getUserEmail());
        values.put(COL_PRICE, item.getPrice());
        values.put(COL_QTY, item.getQuantity());
        values.put(COL_UNIT, item.getCategory());
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Read a single item by ID
    public Item readItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME,
                new String[]{COL_ID, COL_NAME, COL_EMAIL, COL_PRICE, COL_QTY, COL_UNIT},
                COL_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            Item item = new Item(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5)
            );
            cursor.close();
            return item;
        }

        return null;
    }

    // Update an item
    public int updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, item.getitemName());
        values.put(COL_EMAIL, item.getUserEmail());
        values.put(COL_PRICE, item.getPrice());
        values.put(COL_QTY, item.getQuantity());
        values.put(COL_UNIT, item.getCategory());

        return db.update(TABLE_NAME, values, COL_ID + "=?", new String[]{String.valueOf(item.getItemId())});
    }

    // Delete a single item by ID
    public boolean deleteItemById(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_NAME, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    // Delete all items
    public boolean deleteAllItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_NAME, null, null);
        db.close();
        return rows > 0;
    }

    // Get all items
    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                Item item = new Item(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PRICE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_QTY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_UNIT))
                );
                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return itemList;
    }

    // Get item count
    public int getItemsCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // Insert 50 random sample items
    public void insertRandomSampleItems() {
        SQLiteDatabase db = this.getWritableDatabase();

        // Clear the existing table and delete all rows
        db.delete(TABLE_NAME, null, null);

        String[] names = {"Stapler", "Notebook", "Pen", "Pencil", "Eraser", "Ruler", "USB Drive", "HDMI Cable", "Mouse", "Keyboard",
                "Monitor", "Desk Lamp", "Chair", "Desk", "Whiteboard", "Marker", "Paper Clips", "Scissors", "Glue Stick", "Tape",
                "Calculator", "File Folder", "Binder", "Sticky Notes", "Trash Bin", "Water Bottle", "Coffee Mug", "Extension Cord",
                "Laptop Stand", "Phone Charger", "Headphones", "Projector", "Webcam", "Router", "Mouse Pad", "Notebook Cooler",
                "Backpack", "Clipboard", "Highlighter", "Staple Remover", "Label Maker", "Printer", "Ink Cartridge", "Paper Ream",
                "Desk Organizer", "Pen Holder", "Calendar", "Clock", "Surge Protector", "Cleaning Wipes"};

        String[] categories = {"Office", "Electronics", "Furniture", "Accessories", "Utilities", "Kitchen"};

        Random random = new Random();

        // Insert the random items with details (prices, categories)
        for (int i = 0; i < 15; i++) {
            String name = names[random.nextInt(names.length)];
            int quantity = random.nextInt(15) + 1;
            double price = Math.round((1 + random.nextDouble() * 99) * 100.0) / 100.0;
            String category = categories[random.nextInt(categories.length)];

            ContentValues values = new ContentValues();
            values.put(COL_NAME, name);
            values.put(COL_EMAIL, "sampleuser@example.com");
            values.put(COL_PRICE, String.valueOf(price));
            values.put(COL_QTY, String.valueOf(quantity));
            values.put(COL_UNIT, category);

            db.insert(TABLE_NAME, null, values);
        }

        db.close();
    }
}
