package com.example.jessica_ledoux_project_3;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;

import java.util.Random;

public class LetterIconGenerator {

    public static Bitmap create(Context context, String itemName, int dpSize) {
        float scale = context.getResources().getDisplayMetrics().density;
        int pxSize = (int) (dpSize * scale + 0.5f);

        Bitmap bitmap = Bitmap.createBitmap(pxSize, pxSize, Bitmap.Config.ARGB_8888);
        bitmap.setHasAlpha(true);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.TRANSPARENT);

        // Background gradient
        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        int colorStart = Color.parseColor("#98CFDB");
        int colorEnd = Color.parseColor("#0C4964");
        Shader gradient = new LinearGradient(0, 0, pxSize, pxSize,
                colorStart, colorEnd, Shader.TileMode.CLAMP);
        bgPaint.setShader(gradient);
        canvas.drawCircle(pxSize / 2f, pxSize / 2f, pxSize / 2f, bgPaint);

        // Text setup
        String letter = getReadableLetters(itemName);
        Rect bounds = new Rect();

        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(Math.max(pxSize * 0.6f, 12f));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.getTextBounds(letter, 0, letter.length(), bounds);
        float x = pxSize / 2f;
        float y = pxSize / 2f - bounds.exactCenterY();

        // Outline paint
        Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        strokePaint.setColor(Color.WHITE);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(pxSize * 0.05f);
        strokePaint.setTextSize(textPaint.getTextSize());
        strokePaint.setTextAlign(Paint.Align.CENTER);

        // Draw outline then fill
        canvas.drawText(letter, x, y, strokePaint);
        canvas.drawText(letter, x, y, textPaint);

        return bitmap;
    }

    private static int getRandomColor() {
        Random rand = new Random();
        return Color.rgb(rand.nextInt(200), rand.nextInt(200), rand.nextInt(200));
    }

    private static String getReadableLetters(String itemName) {
        if (itemName == null || itemName.trim().isEmpty()) return "?";

        String[] words = itemName.trim().split("\\s+");
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < Math.min(words.length, 3); i++) {
            if (!words[i].isEmpty()) {
                builder.append(Character.toUpperCase(words[i].charAt(0)));
            }
        }

        return builder.length() > 0 ? builder.toString() : "?";
    }

}
