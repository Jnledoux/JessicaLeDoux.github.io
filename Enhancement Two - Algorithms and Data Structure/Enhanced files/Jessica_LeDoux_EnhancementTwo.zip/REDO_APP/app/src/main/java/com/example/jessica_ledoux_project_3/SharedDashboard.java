package com.example.jessica_ledoux_project_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SharedDashboard extends AppCompatActivity {

    private String userName, userEmail, userPhone, userRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_shared);

        // Get user info from intent (login info)
        userName = getIntent().getStringExtra("user_name");
        userEmail = getIntent().getStringExtra("user_email");
        userPhone = getIntent().getStringExtra("user_phone");
        userRole = getIntent().getStringExtra("user_role");

        // Set welcome message
        TextView welcomeText = findViewById(R.id.welcomeMessage);
        welcomeText.setText("Welcome, " + userName);

        // Find all buttons
        Button clerkInventoryBtn = findViewById(R.id.clerk_inventoryBtn);
        Button managerViewReportsBtn = findViewById(R.id.manager_viewReportsBtn);
        Button managerManageUsersBtn = findViewById(R.id.manager_manageUsersBtn);
        Button itSystemLogsBtn = findViewById(R.id.it_systemLogsBtn);
        Button itManageAccessBtn = findViewById(R.id.it_manageAccessBtn);

        // Show/hide buttons based on role
        if ("Clerk".equalsIgnoreCase(userRole)) {
            clerkInventoryBtn.setVisibility(View.VISIBLE);
        }
        else if ("Manager".equalsIgnoreCase(userRole)) {
            managerViewReportsBtn.setVisibility(View.VISIBLE);
            managerManageUsersBtn.setVisibility(View.VISIBLE);
            clerkInventoryBtn.setVisibility(View.VISIBLE);
            itSystemLogsBtn.setVisibility(View.VISIBLE);
            itManageAccessBtn.setVisibility(View.VISIBLE);
        }

        /*
        Want to add IT sometime
        else if ("IT".equalsIgnoreCase(userRole)) {
            itSystemLogsBtn.setVisibility(View.VISIBLE);
            itManageAccessBtn.setVisibility(View.VISIBLE);
        }
        */

        ImageButton debugInsertButton = findViewById(R.id.debug_insert_button);
        debugInsertButton.setOnClickListener(v -> {
            ItemsHandler db = new ItemsHandler(this);
            db.insertRandomSampleItems();
            Toast.makeText(this, "50 random items inserted", Toast.LENGTH_SHORT).show();
        });

        // Optional: Set button actions
        // Launch the inventory grid
        clerkInventoryBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, InventoryGrid.class);
            intent.putExtra("user_name", userName);
            intent.putExtra("user_email", userEmail);
            intent.putExtra("user_phone", userPhone);
            intent.putExtra("user_role", userRole);
            startActivity(intent);

        });

        managerViewReportsBtn.setOnClickListener(v -> {
            // Will lead to Reports
            // startActivity(new Intent(this, ReportsActivity.class));
        });

        managerManageUsersBtn.setOnClickListener(v -> {
            startActivity(new Intent(this, UserListActivity.class));
        });

        itSystemLogsBtn.setOnClickListener(v -> {
            // Will lead to SystemLogs
            // startActivity(new Intent(this, SystemLogsActivity.class));
        });

        itManageAccessBtn.setOnClickListener(v -> {
            // Will lead to AccessControl
            // startActivity(new Intent(this, AccessControlActivity.class));
        });
    }
}
