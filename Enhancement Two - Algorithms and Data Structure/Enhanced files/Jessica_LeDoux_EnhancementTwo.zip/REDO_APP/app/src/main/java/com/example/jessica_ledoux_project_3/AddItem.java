package com.example.jessica_ledoux_project_3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class AddItem extends AppCompatActivity {

    private String Email_Holder;
    private TextView UserEmail;
    private EditText itemNameInput, itemQtyInput, itemPriceInput;
    private ImageButton Increase_Qty, Decrease_Qty;
    private Button addItemBtn, updateItemBtn, deleteItemBtn, cancelBtn;
    private ItemsHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);

        db = new ItemsHandler(this);
        setupViews();
        setupListeners();
    }

    private void setupViews() {
        UserEmail = findViewById(R.id.current_logged_user);
        itemNameInput = findViewById(R.id.itemNameInput);
        itemQtyInput = findViewById(R.id.itemQtyInput);
        itemPriceInput = findViewById(R.id.itemPriceInput);
        Increase_Qty = findViewById(R.id.item_qty_inc);
        Decrease_Qty = findViewById(R.id.item_qty_dec);
        addItemBtn = findViewById(R.id.addItemBtn);
        updateItemBtn = findViewById(R.id.updateItemBtn);
        deleteItemBtn = findViewById(R.id.deleteItemBtn);
        cancelBtn = findViewById(R.id.cancel_button);

        itemQtyInput.setText("0");

        Intent intent = getIntent();
        Email_Holder = intent.getStringExtra(InventoryGrid.UserEmail);
        UserEmail.setText(getString(R.string.logged_user, Email_Holder));

        Increase_Qty.setOnClickListener(view -> {
            int input = parseIntSafe(itemQtyInput.getText().toString());
            itemQtyInput.setText(String.valueOf(input + 1));
        });

        Decrease_Qty.setOnClickListener(view -> {
            int input = parseIntSafe(itemQtyInput.getText().toString());
            if (input > 0) {
                itemQtyInput.setText(String.valueOf(input - 1));
            } else {
                showToast("Item Quantity is Zero");
            }
        });
    }

    private void setupListeners() {
        addItemBtn.setOnClickListener(v -> handleAddItem());
        updateItemBtn.setOnClickListener(v -> showToast("Update feature coming soon"));
        deleteItemBtn.setOnClickListener(v -> handleDeleteItem());
        cancelBtn.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }

    private void handleAddItem() {
        String name = itemNameInput.getText().toString().trim();
        String qtyStr = itemQtyInput.getText().toString().trim();
        String priceStr = itemPriceInput.getText().toString().trim();

        if (name.isEmpty() || qtyStr.isEmpty() || priceStr.isEmpty()) {
            showToast("Please fill in all fields");
            return;
        }

        int qty = parseIntSafe(qtyStr);
        double price = parseDoubleSafe(priceStr);

        Item item = new Item(name, Email_Holder, String.valueOf(price), String.valueOf(qty), "General");

        try {
            db.createItem(item);
            showToast("Item added successfully");
            itemNameInput.setText("");
            itemQtyInput.setText("0");
            itemPriceInput.setText("");
            setResult(RESULT_OK);
            finish();
        } catch (Exception e) {
            showToast("Failed to add item: " + e.getMessage());
        }
    }

    private void handleDeleteItem() {
        String name = itemNameInput.getText().toString().trim();
        if (name.isEmpty()) {
            showToast("Enter item name to delete");
            return;
        }

        List<Item> allItems = db.getAllItems();
        for (Item item : allItems) {
            if (item.getitemName().equalsIgnoreCase(name)) {
                boolean success = db.deleteItemById(item.getItemId());
                showToast(success ? "Item deleted" : "Item not found");
                return;
            }
        }

        showToast("Item not found");
    }


    private int parseIntSafe(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private double parseDoubleSafe(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
