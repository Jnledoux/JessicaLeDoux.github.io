package com.example.jessica_ledoux_project_3;

public class Item {

    private int itemId;
    private String itemName;
    private String userEmail;
    private String price;
    private String quantity;
    private String category;

    // Constructor with ID (used when reading from DB)
    public Item(int itemId, String itemName, String userEmail, String price, String quantity, String category) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.userEmail = userEmail;
        this.price = price;
        this.quantity = quantity;
        this.category = category;
    }

    // Constructor without ID (used when creating new items)
    public Item(String itemName, String userEmail, String price, String quantity, String category) {
        this.itemName = itemName;
        this.userEmail = userEmail;
        this.price = price;
        this.quantity = quantity;
        this.category = category;
    }

    // Getters and setters
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getitemName() {
        return itemName;
    }

    public void setitemName(String itemName) {
        this.itemName = itemName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
