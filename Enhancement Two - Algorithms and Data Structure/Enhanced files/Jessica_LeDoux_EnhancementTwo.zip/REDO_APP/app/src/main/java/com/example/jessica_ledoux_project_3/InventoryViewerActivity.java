package com.example.jessica_ledoux_project_3;

import java.util.List;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class InventoryViewerActivity extends AppCompatActivity {

    private ListView inventoryListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);

        inventoryListView = findViewById(R.id.inventory_list);
        loadInventoryItems();
    }

    private void loadInventoryItems() {
        ItemsHandler db = new ItemsHandler(this);
        List<Item> itemList = db.getAllItems();

        ArrayList<String> items = new ArrayList<>();
        for (Item item : itemList) {
            String name = item.getitemName();
            String qty = item.getQuantity();
            String price = item.getPrice();
            items.add(name + " - Qty: " + qty + ", $" + price);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items);
        inventoryListView.setAdapter(adapter);
    }

}
