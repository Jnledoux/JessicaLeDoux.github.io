package com.example.jessica_ledoux_project_3;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class UserListActivity extends BaseAdapter {

    private final Activity context;
    private final UsersHandler db;
    private ArrayList<User> users;

    public UserListActivity(Activity context, ArrayList<User> users) {
        this.context = context;
        this.users = users;
        this.db = new UsersHandler(context);
    }

    static class ViewHolder {
        ImageView userIcon;
        TextView usernameText;
        TextView userRoleText;
        ImageButton editUserBtn;
        ImageButton deleteUserBtn;
    }

    @Override
    public int getCount() {
        return users.size();
    }

    @Override
    public User getItem(int position) {
        return users.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void updateUsers(ArrayList<User> newUsers) {
        this.users = newUsers;
        notifyDataSetChanged();
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        View rowView;

        if (convertView == null) {
            LayoutInflater inflater = context.getLayoutInflater();
            rowView = inflater.inflate(R.layout.custom_grid_rows, parent, false);

            holder = new ViewHolder();
            holder.userIcon = rowView.findViewById(R.id.userIcon);
            holder.usernameText = rowView.findViewById(R.id.usernameText);
            holder.userRoleText = rowView.findViewById(R.id.userRoleText);
            holder.editUserBtn = rowView.findViewById(R.id.editUserBtn);
            holder.deleteUserBtn = rowView.findViewById(R.id.deleteUserBtn);

            rowView.setTag(holder);
        } else {
            rowView = convertView;
            holder = (ViewHolder) rowView.getTag();
        }

        final int fixedPosition = position;
        final User fixedUser = getItem(position);

        holder.usernameText.setText(fixedUser.getName());
        holder.userRoleText.setText(fixedUser.getRole());

        Bitmap icon = LetterIconGenerator.create(context, fixedUser.getName(), 40);
        holder.userIcon.setImageBitmap(icon);

        SharedPreferences prefs = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        String currentRole = prefs.getString("userRole", "");

        if (currentRole.equals("Manager")) {
            holder.deleteUserBtn.setVisibility(View.VISIBLE);
            holder.editUserBtn.setVisibility(View.VISIBLE);

            holder.deleteUserBtn.setOnClickListener(v -> {
                boolean deleted = db.deleteUserByEmail(fixedUser.getEmail());
                if (deleted) {
                    users.remove(fixedPosition);
                    notifyDataSetChanged();
                    Toast.makeText(context, "User deleted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Failed to delete user", Toast.LENGTH_SHORT).show();
                }
            });

            holder.editUserBtn.setOnClickListener(v -> {
                View popupView = LayoutInflater.from(context).inflate(R.layout.edit_user_popup, null);
                PopupWindow popupWindow = new PopupWindow(popupView,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        true);

                EditText roleInput = popupView.findViewById(R.id.editRoleInput);
                Button saveBtn = popupView.findViewById(R.id.saveRoleBtn);

                roleInput.setText(fixedUser.getRole());

                saveBtn.setOnClickListener(btn -> {
                    String newRole = roleInput.getText().toString().trim();
                    boolean updated = db.updateUserRole(fixedUser.getEmail(), newRole);
                    if (updated) {
                        fixedUser.setRole(newRole);
                        notifyDataSetChanged();
                        popupWindow.dismiss();
                        Toast.makeText(context, "Role updated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                });

                popupWindow.showAtLocation(rowView, Gravity.CENTER, 0, 0);
            });

        } else {
            holder.deleteUserBtn.setVisibility(View.GONE);
            holder.editUserBtn.setVisibility(View.GONE);
        }

        return convertView;
    }
}
