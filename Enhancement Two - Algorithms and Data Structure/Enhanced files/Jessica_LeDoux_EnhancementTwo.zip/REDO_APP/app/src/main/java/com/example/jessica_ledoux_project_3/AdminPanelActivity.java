package com.example.jessica_ledoux_project_3;


import androidx.appcompat.app.AlertDialog;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;


public class AdminPanelActivity extends BaseActivity {
    private Button viewUsersBtn, manageRolesBtn, deleteUserBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_shared);

        viewUsersBtn = findViewById(R.id.manager_manageUsersBtn);
        manageRolesBtn = findViewById(R.id.it_manageAccessBtn);

        // Will launch the user list with all the users
        viewUsersBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, UserListActivity.class);
            startActivity(intent);

            /* Took this out and add it using the BaseActivity Class instead

             overridePendingTransition(R.anim.fade_in, R.anim.fade_out);

             */
        });


        manageRolesBtn.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Edit User Role");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);

            EditText emailInput = new EditText(this);
            emailInput.setHint("User Email");
            layout.addView(emailInput);

            Spinner roleSpinner = new Spinner(this);
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item,
                    new String[]{"Manager", "Clerk"});
            roleSpinner.setAdapter(adapter);
            layout.addView(roleSpinner);

            builder.setView(layout);

            builder.setPositiveButton("Update", (dialog, which) -> {
                String email = emailInput.getText().toString().trim();
                String newRole = roleSpinner.getSelectedItem().toString();

                if (!email.isEmpty()) {
                    UsersHandler db = new UsersHandler(this);
                    boolean updated = db.updateUserRole(email, newRole);
                    String msg = updated ? "Role updated successfully" : "User not found";
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Email cannot be empty", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });


        // Ask for email and what user to delete
        deleteUserBtn.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Delete User");

            final EditText input = new EditText(this);
            input.setHint("Enter user email");
            builder.setView(input);

            builder.setPositiveButton("Delete", (dialog, which) -> {
                String email = input.getText().toString().trim();
                if (!email.isEmpty()) {
                    UsersHandler db = new UsersHandler(this);
                    boolean deleted = db.deleteUserByEmail(email);
                    String msg = deleted ? "User deleted successfully" : "User not found";
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Email cannot be empty", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });

    }
}

