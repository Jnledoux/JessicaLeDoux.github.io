package com.example.jessica_ledoux_project_3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.os.Bundle;
import android.view.View;

public class BaseActivity extends AppCompatActivity {
    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);

        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        if (welcomeMessage != null) {
            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            String name = prefs.getString("userName", "User");
            String role = prefs.getString("userRole", "Unknown");
            welcomeMessage.setText("Welcome, " + name + " (" + role + ")");
        }
    }
}
