package com.example.jessica_ledoux_project_3;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class RegisteredUsersActivity extends AppCompatActivity {

    private ListView userListView;
    private UsersHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered_users);

        userListView = findViewById(R.id.user_list_view);
        dbHandler = new UsersHandler(this);

        List<User> users = dbHandler.getAllUsers();
        List<String> userDisplayList = new ArrayList<>();

        for (User user : users) {
            userDisplayList.add(user.getName() + " | " + user.getEmail() + " | " + user.getRole());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, userDisplayList);
        userListView.setAdapter(adapter);
    }
}

