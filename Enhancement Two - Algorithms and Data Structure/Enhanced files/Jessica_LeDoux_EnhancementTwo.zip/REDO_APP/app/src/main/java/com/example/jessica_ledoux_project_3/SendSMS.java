package com.example.jessica_ledoux_project_3;

import android.widget.Toast;
import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class SendSMS extends AppCompatActivity {

    public interface SmsPermissionCallback {
        void onPermissionGranted();
        void onPermissionDenied();
    }

    public static void checkAndShowSmsDialog(Context context, SmsPermissionCallback callback) {
        SharedPreferences prefs = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        boolean hasResponded = prefs.contains("smsPermissionGranted");

        if (hasResponded) {
            boolean granted = prefs.getBoolean("smsPermissionGranted", false);
            if (granted) {
                callback.onPermissionGranted();
            } else {
                callback.onPermissionDenied();
            }
        } else {
            createSmsPermissionDialog(context, callback).show();
        }
    }

    public static AlertDialog createSmsPermissionDialog(Context context, SmsPermissionCallback callback) {
        return new AlertDialog.Builder(context)
                .setTitle("Enable SMS Alerts?")
                .setMessage("Would you like to receive SMS alerts for zero-value items?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    SharedPreferences prefs = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
                    prefs.edit().putBoolean("smsPermissionGranted", true).apply();
                    InventoryGrid.AllowSendSMS(context);
                    callback.onPermissionGranted();
                })
                .setNegativeButton("No", (dialog, which) -> {
                    SharedPreferences prefs = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
                    prefs.edit().putBoolean("smsPermissionGranted", false).apply();
                    InventoryGrid.DenySendSMS(context);
                    callback.onPermissionDenied();
                })
                .create();
    }
}