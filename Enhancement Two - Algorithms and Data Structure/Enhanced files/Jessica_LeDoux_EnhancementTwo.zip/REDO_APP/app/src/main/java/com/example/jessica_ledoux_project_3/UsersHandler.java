package com.example.jessica_ledoux_project_3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;


public class UsersHandler extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "UsersData.DB";
    public static final int DATABASE_VERSION = 2;

    // Table and column constants
    public static final String TABLE_NAME = "UsersTable";
    public static final String COL_NAME = "name";
    public static final String COL_PHONE = "phone_number";
    public static final String COL_EMAIL = "email";
    public static final String COL_PASSWORD = "password";
    public static final String COL_ROLE = "role";


    public UsersHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_NAME + " TEXT," +
                COL_PHONE + " TEXT," +
                COL_EMAIL + " TEXT UNIQUE," +
                COL_PASSWORD + " TEXT," +
                COL_ROLE + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);
    }


    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /**
     * Database CRUD (Create, Read, Update, Delete) Operations
     */

    //  Users and the tasks that apply all to its variables
    // Create users with an extra check
    public boolean createUser(User user) {
        if (getUserByEmail(user.getEmail()) != null) {
            return false; // user already exists
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, user.getName());
        values.put(COL_PHONE, user.getPhone());
        values.put(COL_EMAIL, user.getEmail());
        values.put(COL_PASSWORD, user.getPassword());
        values.put(COL_ROLE, user.getRole());

        long result = db.insert(TABLE_NAME, null, values);
        db.close();
        return result != -1;
    }

    // Get user by email
    public User getUserByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, COL_EMAIL + "=?", new String[]{email},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(COL_PHONE));
            String password = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD));
            String role = cursor.getString(cursor.getColumnIndexOrThrow(COL_ROLE));
            cursor.close();
            db.close();
            return new User(name, phone, email, password, role);
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    // Update user role
    public boolean updateUserRole(String email, String newRole) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ROLE, newRole);
        int rows = db.update(TABLE_NAME, values, COL_EMAIL + "=?", new String[]{email});
        db.close();
        return rows > 0;
    }

    // Delete user by email
    public boolean deleteUserByEmail(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_NAME, COL_EMAIL + "=?", new String[]{email});
        db.close();
        return rows > 0;
    }

    // Get all users
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(COL_PHONE));
                String email = cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL));
                String password = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD));
                String role = cursor.getString(cursor.getColumnIndexOrThrow(COL_ROLE));

                User user = new User(name, phone, email, password, role);
                userList.add(user);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return userList;
    }
}