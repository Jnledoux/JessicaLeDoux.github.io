package com.example.jessica_ledoux_project_3;

import androidx.appcompat.app.AlertDialog;

public class DeleteAllItems {
    public static AlertDialog doubleButton(final InventoryGrid context){
        // Using a builder class for messages
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.delete_all)
                .setIcon(R.drawable.delete_all_items)
                .setCancelable(false)
                .setMessage(R.string.delete_all_msg)
                .setPositiveButton(R.string.delete_all_yes, (dialog, arg1) -> {
                    InventoryGrid.YesDeleteItems();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.delete_all_no, (dialog, arg1) -> {
                    InventoryGrid.NoDeleteItems();
                    dialog.cancel();
                });
        return builder.create();
    }
}

