package com.example.jessica_ledoux_project_3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class UsersHandler extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DATABASE_NAME = "UsersData.DB";
    public static final String TABLE_NAME = "UsersTable";
    public static final String ID_COL = "id";
    public static final String NAME_COL = "name";
    public static final String PHONE_NUMBER_COL = "phone_number";
    public static final String EMAIL_COL = "email";
    public static final String PASSWORD_COL = "password";

    private static final String CREATE_USERS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            NAME_COL + " VARCHAR, " +
            PHONE_NUMBER_COL + " VARCHAR, " +
            EMAIL_COL + " VARCHAR, " +
            PASSWORD_COL + " VARCHAR" + ");";

    public UsersHandler(Context context) {
        super(context, DATABASE_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase dbHandler, int oldVersion, int newVersion) {
        dbHandler.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(dbHandler);
    }

    /**
     * Database CRUD (Create, Read, Update, Delete) Operations
     */

    // Adding user and all its variables to database
    public void createUser(User user) {
        SQLiteDatabase dbHandler = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NAME_COL, user.getUserName());
        values.put(PHONE_NUMBER_COL, user.getUserPhone());
        values.put(EMAIL_COL, user.getUserEmail());
        values.put(PASSWORD_COL, user.getUserPass());

        dbHandler.insert(TABLE_NAME, null, values);
        dbHandler.close();
    }

    // Reading user and variables from database
    public User readUser(int id) {
        SQLiteDatabase dbHandler = this.getReadableDatabase();

        Cursor cursor = dbHandler.query(TABLE_NAME,
                new String[] { ID_COL, NAME_COL, PHONE_NUMBER_COL, EMAIL_COL, PASSWORD_COL }, ID_COL + " = ?",
                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        User user = new User(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));

        cursor.close();

        return user;
    }

    // Updating user and variables in database
    public int updateUser(User user) {
        SQLiteDatabase dbHandler = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NAME_COL, user.getUserName());
        values.put(PHONE_NUMBER_COL, user.getUserPhone());
        values.put(EMAIL_COL, user.getUserEmail());
        values.put(PASSWORD_COL, user.getUserPass());

        return dbHandler.update(TABLE_NAME, values, ID_COL + " = ?", new String[] { String.valueOf(user.getId()) });
    }

    // Deleting user from the database
    public void deleteItem(User user) {
        SQLiteDatabase dbHandler = this.getWritableDatabase();

        dbHandler.delete(TABLE_NAME, ID_COL + " = ?", new String[] { String.valueOf(user.getId()) });
        dbHandler.close();
    }

    /**
     * Global Database Operations
     */

    // List to get all users from Array
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase dbHandler = this.getWritableDatabase();
        Cursor cursor = dbHandler.rawQuery(selectQuery, null);

        // Adding to the list by a do loop
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(0)));
                user.setUserName(cursor.getString(1));
                user.setUserPhone(cursor.getString(2));
                user.setUserEmail(cursor.getString(3));
                user.setUserPass(cursor.getString(4));

                userList.add(user);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return userList;
    }

    // Deleting all users variables from the database
    public void deleteAllUsers() {
        SQLiteDatabase dbHandler = this.getWritableDatabase();
        dbHandler.delete(TABLE_NAME,null,null);
        dbHandler.close();
    }

    // Getting total users from the database
    public int getUsersCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase dbHandler = this.getReadableDatabase();
        Cursor cursor = dbHandler.rawQuery(countQuery, null);
        int usersTotal = cursor.getCount();
        cursor.close();

        return usersTotal;
    }

}

