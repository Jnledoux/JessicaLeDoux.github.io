package com.example.jessica_ledoux_project_3;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CustomItemsList extends BaseAdapter {
    private final Activity context;
    private PopupWindow popwindow;
    ArrayList<Item> items;
    ItemsHandler db;

    public CustomItemsList(Activity context, ArrayList<Item> items, ItemsHandler db) {
        this.context = context;
        this.items = items;
        this.db = db;
    }

    public static class ViewHolder {
        TextView Item_Name;
        TextView Item_Description;
        TextView Item_Quantity;
        TextView Item_Category;
        ImageButton Edit_Button;
        ImageButton Delete_Button;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;

        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.custom_grid_rows, null, true);

            // Initiate variables, buttons, and databases
            vh.Edit_Button = row.findViewById(R.id.grid_image);
            vh.Item_Description = row.findViewById(R.id.custom_item_desc);
            vh.Item_Quantity = row.findViewById(R.id.custom_item_qty);
            vh.Item_Category = row.findViewById(R.id.custom_item_category);
            vh.Delete_Button = row.findViewById(R.id.custom_delete);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        vh.Item_Description.setText(items.get(position).getDesc());;
        vh.Item_Quantity.setText(items.get(position).getQty());
        vh.Item_Category.setText(items.get(position).getCategory());

        // Check if qty was 0 and alert (message/change color)
        String value = vh.Item_Quantity.getText().toString().trim();
        if (value.equals("0")) {
            // background changed to red for alert
            vh.Item_Quantity.setBackgroundColor(Color.RED);
            vh.Item_Quantity.setTextColor(Color.WHITE);
            InventoryGrid.SendSMSMessage(context.getApplicationContext());
        } else {
            // change background to default
            vh.Item_Quantity.setBackgroundColor(Color.parseColor("#E6E6E6"));
            vh.Item_Quantity.setTextColor(Color.BLACK);
        }

        final int positionPopup = position;

        vh.Edit_Button.setOnClickListener(view -> editPopup(positionPopup));

        vh.Delete_Button.setOnClickListener(view -> {

            db.deleteItem(items.get(positionPopup));

            items = (ArrayList<Item>) db.getAllItems();
            notifyDataSetChanged();

            Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show();

            int itemsCount = db.getItemsCount();
            TextView TotalItems = context.findViewById(R.id.total_item_amount);
            TotalItems.setText(String.valueOf(itemsCount));
        });

        return  row;
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public int getCount() {
        return items.size();
    }

    // pop up menu to edit item
    public void editPopup(final int positionPopup) {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.edit_item_popup, context.findViewById(R.id.edit_popup_element));

        popwindow = new PopupWindow(layout, 800, 1000, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        final EditText editItemDesc = layout.findViewById(R.id.edit_item_desc);
        final EditText editItemQty = layout.findViewById(R.id.edit_item_qty);
        final EditText editItemUnit = layout.findViewById(R.id.edit_item_cat);

        editItemDesc.setText(items.get(positionPopup).getDesc());
        editItemQty.setText(items.get(positionPopup).getQty());
        editItemUnit.setText(items.get(positionPopup).getCategory());

        Button save = layout.findViewById(R.id.editSaveButton);
        Button cancel = layout.findViewById(R.id.edit_cancel_button);

        // adding on click lister to save updates
        save.setOnClickListener(view -> {
            String itemDesc = editItemDesc.getText().toString();
            String itemQty = editItemQty.getText().toString();
            String itemUnit = editItemUnit.getText().toString();

            Item item = items.get(positionPopup);
            item.setDesc(itemDesc);
            item.setQty(itemQty);
            item.setCategory(itemUnit);

            db.updateItem(item);
            items = (ArrayList<Item>) db.getAllItems();
            notifyDataSetChanged();

            Toast.makeText(context, "Item Updated", Toast.LENGTH_SHORT).show();

            popwindow.dismiss();
        });

        // adding on click lister for cancel button
        cancel.setOnClickListener(view -> {
            Toast.makeText(context, "Action Canceled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
    }

}

